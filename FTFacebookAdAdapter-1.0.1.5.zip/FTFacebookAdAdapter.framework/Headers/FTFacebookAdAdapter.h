//
//  FTFacebookAdAdapter.h
//  FTFacebookAdAdapter
//
//  Created by fotoable on 2020/3/22.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTFacebookAdAdapter.
FOUNDATION_EXPORT double FTFacebookAdAdapterVersionNumber;

//! Project version string for FTFacebookAdAdapter.
FOUNDATION_EXPORT const unsigned char FTFacebookAdAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTFacebookAdAdapter/PublicHeader.h>

#import <FTFacebookAdAdapter/FTFacebookBannerAdTask.h>
#import <FTFacebookAdAdapter/FTFacebookIntersitialAdTask.h>
#import <FTFacebookAdAdapter/FTFacebookRewardAdTask.h>
#import <FTFacebookAdAdapter/FTFacebookManagerAdapter.h>


