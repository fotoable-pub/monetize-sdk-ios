//
//  FTLNetWork.h
//  FTLogger
//
//  Created by fotoable on 2020/4/27.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FTCoreRequest;
@protocol FTCoreResponse;

typedef void(^Success)(id _Nullable data);
typedef void(^Fail)(NSError * _Nonnull error);

NS_ASSUME_NONNULL_BEGIN

@interface FTCoreNetWork : NSObject

//请求域名
@property (nonatomic, copy, readonly) NSString *apiHost;

//公共http header
@property (nonatomic, strong) NSDictionary *headers;

/// @param host 请求服务器地址
- (instancetype)initWithHost:(NSString *)host;


- (void)HTTPRequest:(id<FTCoreRequest>)request
           response:(nullable id<FTCoreResponse>)response
            success:(Success)success
               fail:(Fail)fail;
@end

NS_ASSUME_NONNULL_END
