//
//  FTCore.h
//  FTCore
//
//  Created by fotoable on 2020/4/29.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTCore.
FOUNDATION_EXPORT double FTCoreVersionNumber;

//! Project version string for FTCore.
FOUNDATION_EXPORT const unsigned char FTCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTCore/PublicHeader.h>

//network
#import <FTCore/FTCoreHttp.h>
#import <FTCore/FTCoreNetWork.h>
#import <FTCore/FTCoreRequest.h>
#import <FTCore/FTCoreResponse.h>
#import <FTCore/NSString+URL.h>


//appInfo
#import <FTCore/FTCoreAppInfo.h>
#import <FTCore/FTCoreBatteryInfo.h>
#import <FTCore/FTCoreDeviceDataLibrery.h>
#import <FTCore/FTCoreDeviceInfo.h>
#import <FTCore/FTCoreNetWorkInfo.h>

