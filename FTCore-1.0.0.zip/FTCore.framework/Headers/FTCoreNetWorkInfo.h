//
//  FTNetWorkInfo.h
//  FTLogger
//
//  Created by fotoable on 2020/4/28.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTCoreNetWorkInfo : NSObject
+ (instancetype)shared;

/** 获取ip */
- (NSString *)getDeviceIPAddresses;

- (NSString *)getIpAddressWIFI;
- (NSString *)getIpAddressCell;

- (NSString *)internetStatus;

@end

NS_ASSUME_NONNULL_END
