//
//  FTRequest.h
//  FTLogger
//
//  Created by fotoable on 2020/4/28.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, FTHttpRequestMethod) {
    FTHttpRequestMethodGet,
    FTHttpRequestMethodPost,
};

@protocol FTCoreRequest <NSObject>

- (NSString *)requestURLString;

- (FTHttpRequestMethod)requestMethod;

@optional

- (NSDictionary *)headers;

- (BOOL)containsBody;

- (nullable id)unencodedHTTPRequestBodyWithError:(NSError *_Nullable *_Nullable)error;

@end

NS_ASSUME_NONNULL_END
