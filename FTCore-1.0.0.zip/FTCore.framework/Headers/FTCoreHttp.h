//
//  FTLHttpTool.h
//  FTLogger
//
//  Created by fotoable on 2020/4/27.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

typedef void(^HttpSuccess)(id _Nullable data);
typedef void(^HttpFail)(NSError * _Nonnull error);

@interface FTCoreHttp : NSObject
+ (void)POSTWithUrl:(NSURL *)url
           postBody:(NSData *)postBody
            success:(HttpSuccess)success
               fail:(HttpFail)fail;

+ (void)GETWithUrl:(NSURL *)url
           success:(HttpSuccess)success
              fail:(HttpFail)fail;

+ (void)URLSessionTaskSendWithRequest:(NSURLRequest *)request
                              success:(HttpSuccess)success
                                 fail:(HttpFail)fail ;

@end

NS_ASSUME_NONNULL_END
