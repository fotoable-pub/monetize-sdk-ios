//
//  FATBaseAd.h
//  FAT_ads
//
//  Created by 傅瑶fotoable on 2019/6/18.
//  Copyright © 2019 FOTOABLE. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IFATAd.h"
#import "FATAdModel.h"

NS_ASSUME_NONNULL_BEGIN


@interface FATBaseAd : NSObject<IFATAd>

/**
 广告资源已经缓存完成,并且没有展示过 为YES,否则为NO
 */
@property (nonatomic, getter=isAdValid, readonly) BOOL adValid;


- (void)jumpToAppStore:(FATAdModel *)admodel
         PresentRootVc:(UIViewController*)presentRootVc;
@end



NS_ASSUME_NONNULL_END
