//
//  FATAdModel.h
//  FAT_ads
//
//  Created by 傅瑶fotoable on 2019/6/25.
//  Copyright © 2019 FOTOABLE. All rights reserved.
//

#import "FATBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSInteger {
    innerStore = 1,//应用内打开 storeProductVc
    outStore = 2,//打开appStore app
} Jump2AppStoreType;


/*
 {
     adid = 210;
     bundle = 1413608864;
     button =     {
     };
     ctrk =     (
         "http://192.168.1.53:50000/track?type=c&bid=8f0fc71b-ea63-4f7a-879a-e2c20751ec8e&adid=210&adsetid=124&appid=100036&placementId=329&deviceID=5DFE3BC5-ADD7-42B2-AAA7-4B0CFD85CF3D&android_id=&gaid=&idfa=5DFE3BC5-ADD7-42B2-AAA7-4B0CFD85CF3D&brand=iPhone12,1&model=iPhone12,1&os=1&os_version=13.3&country="
     );
     "ctrk_target" = 1;
     icon = "http://adsres.ftstats.com/arlington/202001/673cc240ef77739a1eb9d54476b20f06.png";
     id = 329;
     img =     {
     };
     "img_slides" =     (
         "https://is3-ssl.mzstatic.com/image/thumb/Purple123/v4/52/35/5a/52355a55-39da-e63b-c364-5ed061a1be37/mzl.homqgzqk.jpg/392x696bb.jpg",
         "https://is2-ssl.mzstatic.com/image/thumb/Purple113/v4/20/3c/ad/203cad20-43b6-5e4e-2a1f-66f8d8737bb7/mzl.etauzpmr.jpg/392x696bb.jpg",
         "https://is5-ssl.mzstatic.com/image/thumb/Purple123/v4/f5/02/3c/f5023c7d-db47-7a34-fd1b-c1f171d37699/mzl.avcvrkzx.jpg/392x696bb.jpg",
         "https://is5-ssl.mzstatic.com/image/thumb/Purple123/v4/59/38/fc/5938fc15-baab-e65e-b9ec-b445e155490e/mzl.yzoslsay.jpg/392x696bb.jpg",
         "https://is3-ssl.mzstatic.com/image/thumb/Purple123/v4/57/1b/7d/571b7d53-841e-805c-89a3-17f60022f871/mzl.efuqwiek.jpg/392x696bb.jpg",
         "https://is5-ssl.mzstatic.com/image/thumb/Purple113/v4/8e/e8/1e/8ee81e8b-e14f-2a8a-1e03-b7cbc32cd68d/mzl.nnapaona.jpg/392x696bb.jpg",
         "https://is4-ssl.mzstatic.com/image/thumb/Purple113/v4/25/ae/cc/25aecc54-8613-3f2c-247a-2d2d5d27260d/mzl.cffrqpqi.jpg/392x696bb.jpg",
         "https://is3-ssl.mzstatic.com/image/thumb/Purple123/v4/fa/72/ef/fa72efcb-7226-9146-9876-229b524d1164/mzl.rqchtloz.jpg/392x696bb.jpg",
         "https://is2-ssl.mzstatic.com/image/thumb/Purple113/v4/af/57/43/af5743b9-1a4a-d8b8-36f0-13b395ac6ff3/mzl.pjhaiyto.jpg/576x768bb.jpg",
         "https://is5-ssl.mzstatic.com/image/thumb/Purple113/v4/75/08/58/75085873-de22-9bd7-1f9a-724612d876bd/mzl.pdwxzgkg.jpg/576x768bb.jpg",
         "https://is1-ssl.mzstatic.com/image/thumb/Purple123/v4/57/ec/2f/57ec2f69-d79b-69ec-924d-7e8d34e0e471/mzl.txjndymv.jpg/576x768bb.jpg",
         "https://is2-ssl.mzstatic.com/image/thumb/Purple123/v4/ef/cf/0a/efcf0a04-dc68-9d10-8f31-9cbdc7160e66/mzl.jghlvpso.jpg/576x768bb.jpg",
         "https://is2-ssl.mzstatic.com/image/thumb/Purple113/v4/92/bc/6a/92bc6a11-82cd-1ac2-96bb-5fb5676e6ef7/mzl.cppjhwrj.jpg/576x768bb.jpg"
     );
     itrk =     (
         "https://itunes.apple.com/app/id1413608864",
         "http://192.168.1.53:50000/track?type=i&bid=8f0fc71b-ea63-4f7a-879a-e2c20751ec8e&adid=210&adsetid=124&appid=100036&placementId=329&deviceID=5DFE3BC5-ADD7-42B2-AAA7-4B0CFD85CF3D&android_id=&gaid=&idfa=5DFE3BC5-ADD7-42B2-AAA7-4B0CFD85CF3D&brand=iPhone12,1&model=iPhone12,1&os=1&os_version=13.3&country="
     );
     name = "Word Slices";
     nativead =     {
     };
     score = "4.5";
     title = 1;
     turl = "https://itunes.apple.com/app/id1413608864";
     type = 4;
     video =     {
         dur = "19.52";
         h = 750;
         url = "https://adsres.ftstats.com/arlington/201908/1565944279560.mp4";
         w = 600;
     };
 }
 */

/**
 广告公共信息
 */
@interface FATAdModel : FATBaseModel


///广告id,标识素材
@property (nonatomic, copy) NSString *adid;
///苹果商店应用id
@property (nonatomic, copy) NSString *bundle;
/// 点击上报
@property (nonatomic, strong) NSArray <NSString *>*clickTrackUrls;
///Logo
@property (nonatomic, copy) NSString *icon;
///广告位ID
@property (nonatomic, copy) NSString *ID;
///展示上报地址
@property (nonatomic, strong) NSArray <NSString *>*displayTrackUrls;
///应用名称
@property (nonatomic, copy) NSString *name;
///评分
@property (nonatomic, copy) NSString *score;
///目标地址
@property (nonatomic, copy) NSString *turl;
///广告类型,0:插播,1: Banner, 2:按钮,4: 激励视频,5原生广告
@property (nonatomic, assign) NSInteger type;
///下载按钮的文字
@property (nonatomic, copy) NSString *title;
/// 商店跳转方式
@property (nonatomic, assign) Jump2AppStoreType ctrk_target;
///落地页素材
@property (nonatomic, strong) NSArray* img_slides;

///广告行为的唯一标识,用于track
@property (nonatomic, copy) NSString *bid;

@end


/*
 {
 h = 691;
 url = "https://adsres.ftstats.com/arlington/201906/201906171530075166959163163.png";
 w = 599;
 }
 */
@interface  FATAdImage : FATBaseModel
@property (nonatomic, assign) NSInteger h;
@property (nonatomic, assign) NSInteger w;
@property (nonatomic, copy) NSString *url;
@end

/*
 {
 dur = 15;
 etrk =
 (
 );
 h = 640;
 strk =
 (
 );
 tgpctrk =
 (
 );
 tgpstrk =
 (
 );
 url = "https://adsres.ftstats.com/arlington/201906/201906130249456887932994610.mp4";
 w = 360;
 }
 */
@interface FATAdVideo : FATBaseModel

@property (nonatomic, assign) NSInteger dur;
@property (nonatomic, assign) NSInteger h;
@property (nonatomic, assign) NSInteger w;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, strong) NSArray *etrk;
@property (nonatomic, strong) NSArray *strk;
@property (nonatomic, strong) NSArray *tgpctrk;
@property (nonatomic, strong) NSArray *tgpstrk;

@end

NS_ASSUME_NONNULL_END
