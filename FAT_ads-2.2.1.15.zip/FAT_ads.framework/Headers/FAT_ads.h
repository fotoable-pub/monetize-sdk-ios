//
//  FAT_ads.h
//  FAT_ads
//
//  Created by 傅瑶fotoable on 2019/7/1.
//  Copyright © 2019 FOTOABLE. All rights reserved.
//

#ifndef FAT_ads_h
#define FAT_ads_h

#import <UIKit/UIKit.h>
// In this header, you should import all the public headers of your framework using statements like #import <FAT_ads/FATSDKManager.h>

#import <FAT_ads/FATSDKManager.h>
#import <FAT_ads/IFATAd.h>

#import <FAT_ads/FATBaseAd.h>
#import <FAT_ads/FATInterstitialAd.h>
#import <FAT_ads/FATNativeAd.h>
#import <FAT_ads/FATRewardVideoAd.h>




#endif /* FAT_ads_h */
