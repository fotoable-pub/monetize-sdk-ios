//
//  FTSDKLogin.h
//  FTSDKLogin
//
//  Created by fotoable on 2020/3/20.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTSDKLogin.
FOUNDATION_EXPORT double FTSDKLoginVersionNumber;

//! Project version string for FTSDKLogin.
FOUNDATION_EXPORT const unsigned char FTSDKLoginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTSDKLogin/PublicHeader.h>

#import <FTSDKLogin/FTLoginManager.h>
