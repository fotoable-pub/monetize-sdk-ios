//
//  FTAppLovinIntersitialAdTask.h
//  FTAppLovinAdAdapter
//
//  Created by fotoable on 2020/2/25.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FTAdBaseAdapter/FTAdBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTAppLovinIntersitialAdTask : NSObject<FTBaseIntersitialAdapter>

@end

NS_ASSUME_NONNULL_END
