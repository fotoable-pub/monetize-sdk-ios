//
//  FTAppLovinAdAdapter.h
//  FTAppLovinAdAdapter
//
//  Created by fotoable on 2020/2/25.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTAppLovinAdAdapter.
FOUNDATION_EXPORT double FTAppLovinAdAdapterVersionNumber;

//! Project version string for FTAppLovinAdAdapter.
FOUNDATION_EXPORT const unsigned char FTAppLovinAdAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTAppLovinAdAdapter/PublicHeader.h>
#import <FTAppLovinAdAdapter/FTAppLovinManagerAdapter.h>
#import <FTAppLovinAdAdapter/FTAppLovinIntersitialAdTask.h>
#import <FTAppLovinAdAdapter/FTAppLovinRewardAdTask.h>

