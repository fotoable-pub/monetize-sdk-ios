//
//  FTResponse.h
//  FTLogger
//
//  Created by fotoable on 2020/4/28.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol FTCoreResponse <NSObject>
- (BOOL)setWithDictionary:(NSDictionary *)dictionary
                    error:(NSError *_Nullable *_Nullable)error;
@end

NS_ASSUME_NONNULL_END
