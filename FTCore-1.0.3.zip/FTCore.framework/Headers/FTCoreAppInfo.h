//
//  FTAppInfo.h
//  FTLogger
//
//  Created by fotoable on 2020/4/28.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTCoreAppInfo : NSObject

+ (instancetype)shared;

/// 应用名
- (NSString *)appName;
///应用版本
- (NSString *)appVersion;
///bundle id
- (NSString *)bundleId;



@end

NS_ASSUME_NONNULL_END
