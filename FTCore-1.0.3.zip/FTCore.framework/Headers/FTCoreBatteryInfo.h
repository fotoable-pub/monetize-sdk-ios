//
//  FTBatteryInfo.h
//  FTLogger
//
//  Created by fotoable on 2020/4/28.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol FTBatteryInfoDelegate
- (void)batteryStatusUpdated;
@end

@interface FTCoreBatteryInfo : NSObject
@property (nonatomic, weak) id<FTBatteryInfoDelegate> delegate;

@property (nonatomic, assign) NSUInteger capacity;
@property (nonatomic, assign) CGFloat voltage;

@property (nonatomic, assign) NSUInteger levelPercent;
@property (nonatomic, assign) NSUInteger levelMAH;
@property (nonatomic, copy)   NSString *status;

+ (instancetype)shared;
/** 开始监测电池电量 */
- (void)startBatteryMonitoring;
/** 停止监测电池电量 */
- (void)stopBatteryMonitoring;
@end

NS_ASSUME_NONNULL_END
