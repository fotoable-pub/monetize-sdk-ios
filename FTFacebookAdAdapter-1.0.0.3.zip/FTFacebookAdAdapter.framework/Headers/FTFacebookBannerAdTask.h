//
//  FTFacebookBannerAdTask.h
//  FTFacebookAdAdapter
//
//  Created by fotoable on 2020/1/4.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FBAudienceNetwork/FBAudienceNetwork.h>
#import <FTAdBaseAdapter/FTAdBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTFacebookBannerAdTask : NSObject<FTBaseBannerAdapter>

@end

NS_ASSUME_NONNULL_END
