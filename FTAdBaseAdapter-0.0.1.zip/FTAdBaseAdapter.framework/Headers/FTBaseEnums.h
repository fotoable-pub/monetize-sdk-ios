//
//  FTBaseEnums.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseEnums_h
#define FTBaseEnums_h

//SDK banner广告位置
typedef enum : NSUInteger {
    FTBase_Bottom,
    FTBase_Top,
} FTBase_AD_BANNER_POSITION;

//SDK banner尺寸
typedef enum : NSUInteger {
    //320x50
    FTBase_Standard_50,
    //320x250
    FTBase_Medium_250,
    //320x90
    FTBase_Large_90,
} FTBase_AD_BANNER_SIZE;

#endif /* FTBaseEnums_h */
