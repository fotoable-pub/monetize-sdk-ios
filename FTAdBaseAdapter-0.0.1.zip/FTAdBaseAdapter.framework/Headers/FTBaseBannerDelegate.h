//
//  FTBaseBannerDelegate.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseBannerDelegate_h
#define FTBaseBannerDelegate_h
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol FTBaseBannerDelegate <NSObject>

- (void) onBannerAdLoad: (NSString *)adID;

- (void) onBannerAdLoadFail: (NSString *)adID error:(NSError *)error;

- (void) onBannerAdDisplay: (NSString *)adID;

- (void) onBannerAdDisplayFail: (NSString *)adID error:(NSError *)error;

- (void) onBannerAdClose: (NSString *)adID;

- (void) onBannerAdClick: (NSString *)adID;

@end
#endif /* FTBaseBannerDelegate_h */
