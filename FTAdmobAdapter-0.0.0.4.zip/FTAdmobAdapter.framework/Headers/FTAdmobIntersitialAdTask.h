//
//  FTAdmobIntersitialAdTask.h
//  FTAdmobAdapter
//
//  Created by fotoable on 2020/1/21.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FTAdBaseAdapter/FTAdBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTAdmobIntersitialAdTask : NSObject<FTBaseIntersitialAdapter>

@end

NS_ASSUME_NONNULL_END
