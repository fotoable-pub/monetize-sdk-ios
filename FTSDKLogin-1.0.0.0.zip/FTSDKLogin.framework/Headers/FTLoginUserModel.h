//
//  FTLoginUserModel.h
//  FTSDKLogin
//
//  Created by fotoable on 2020/3/23.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FTLoginUserRelatedAccountModel.h"
#import "FTLoginEnums.h"

NS_ASSUME_NONNULL_BEGIN

@interface FTLoginUserModel : NSObject

@property(nonatomic, copy, nonnull) NSString *userID;
@property(nonatomic, copy, nonnull) NSString *sessionID;
///用户状态 1 正常
@property(nonatomic, assign) FTLogin_USER_STATUS userStatus;
///用户类型 1 正常用户 2 游客
@property(nonatomic, assign) FTLogin_USER_TYPE userType;
///玩家ID
@property(nonatomic, copy) NSString *gamePlayerId;
///游戏ID
@property(nonatomic, copy) NSString *gameId;
///最近登录平台
@property(nonatomic, assign) FTLogin_PLATFORM lastLoginPlatform;
///最近登录时间
@property(nonatomic, copy) NSString *lastLoginTime;
///第三方平台
@property(nonatomic, strong) NSMutableArray<FTLoginUserRelatedAccountModel*> *accountRelateds;


@end

NS_ASSUME_NONNULL_END
