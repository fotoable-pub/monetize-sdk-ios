//
//  FTLoginEnums.h
//  FTSDKLogin
//
//  Created by fotoable on 2020/3/23.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTLoginEnums_h
#define FTLoginEnums_h

///**登录平台**/
//typedef NS_OPTIONS(NSInteger, FTLogin_Kind){
//    FTLogin_Kind_Tourists = -1,
//    FTLogin_Kind_Apple = 0,
//    FTLogin_Kind_Facebook = 1,
//};

//上报平台类型
typedef NS_OPTIONS(NSInteger, FTLogin_LOG_TYPE) {
    
    FTLogin_NSLOG    = 1 << 0, //  0001  1
    FTLogin_UNITYLOG  = 1 << 1, //  0010  2
    FTLogin_SERVER  = 1 << 2, //  0100  4
};

//上报平台类型
typedef NS_OPTIONS(NSInteger, FTLogin_LOG_LEVEL_TYPE) {
    
    FTLogin_GENERAL    = 1 << 0, //  0001  1
    FTLogin_WARNING  = 1 << 1, //  0010  2
    FTLogin_ERROR  = 1 << 2, //  0100  4
};

//用户状态
typedef NS_OPTIONS(NSInteger, FTLogin_USER_STATUS) {
    //正常用户
    FTLogin_USER_STATUS_NORMAL    = 1,
};

//用户类型
typedef NS_OPTIONS(NSInteger, FTLogin_USER_TYPE) {
    //正常用户
    FTLogin_USER_TYPE_NORMAL    = 1,
    //游客
    FTLogin_USER_TYPE_Tourists    = 2,
};

//用户所属的平台
typedef NS_OPTIONS(NSInteger, FTLogin_PLATFORM) {
    //未知
    FTLogin_PLATFORM_UNKNOW   = 0,
    //苹果用户
    FTLogin_PLATFORM_APPLE    = 1,
    //游客
    FTLogin_PLATFORM_Tourists   = 2,
    //Facebook
    FTLogin_PLATFORM_Facebook   = 3,
};

#endif /* FTLoginEnums_h */
