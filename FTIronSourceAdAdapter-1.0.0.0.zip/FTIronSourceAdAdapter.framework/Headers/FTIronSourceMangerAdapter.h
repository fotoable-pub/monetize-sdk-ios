//
//  FTIronSourceMangerAdapter.h
//  FTIronSourceAdAdapter
//
//  Created by fotoable on 2020/2/19.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FTAdBaseAdapter/FTAdBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTIronSourceMangerAdapter : NSObject<FTBaseManagerAdapter>

//单例
+ (instancetype)getInstance;
/// 设置对外回调
/// @param adID 第三方广告ID
/// @param delegate 回调
- (void) setDelegateWithAdID:(NSString *)adID delegate:(id)delegate;
@end

NS_ASSUME_NONNULL_END
