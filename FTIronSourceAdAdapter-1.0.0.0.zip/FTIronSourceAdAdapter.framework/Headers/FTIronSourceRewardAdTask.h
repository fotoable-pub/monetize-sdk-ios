//
//  FTIronSourceRewardAdTask.h
//  FTIronSourceAdAdapter
//
//  Created by fotoable on 2020/2/19.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <FTAdBaseAdapter/FTAdBaseAdapter.h>
#import "FTIronSourceMangerAdapter.h"

NS_ASSUME_NONNULL_BEGIN

@interface FTIronSourceRewardAdTask : NSObject<FTBaseRewardAdapter>

@end

NS_ASSUME_NONNULL_END
