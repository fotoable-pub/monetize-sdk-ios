//
//  FTIronSourceAdAdapter.h
//  FTIronSourceAdAdapter
//
//  Created by fotoable on 2020/2/19.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTIronSourceAdAdapter.
FOUNDATION_EXPORT double FTIronSourceAdAdapterVersionNumber;

//! Project version string for FTIronSourceAdAdapter.
FOUNDATION_EXPORT const unsigned char FTIronSourceAdAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTIronSourceAdAdapter/PublicHeader.h>
#import <FTIronSourceAdAdapter/FTIronSourceRewardAdTask.h>
#import <FTIronSourceAdAdapter/FTIronSourceIntersitialAdTask.h>
#import <FTIronSourceAdAdapter/FTIronSourceMangerAdapter.h>

