//
//  FTBaseBannerAdapter.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseBannerAdapter_h
#define FTBaseBannerAdapter_h
#import "FTBaseEnums.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "FTBaseBannerDelegate.h"

@protocol FTBaseBannerAdapter <NSObject>
 
- (void) requestAd: (NSString *) adID bannerPosition: (FTBase_AD_BANNER_POSITION) position size: (FTBase_AD_BANNER_SIZE) size rootViewController:(UIViewController *) viewController;;
- (BOOL) isAdValid;
- (BOOL) showAdWithViewController: (UIViewController *)viewController;
- (void) hiddenBannerAd;
- (void) setBannerDelegate: (id<FTBaseBannerDelegate>) bannerDelegate ;
@end

#endif /* FTBaseBannerAdapter_h */
