//
//  FTBaseRewardAdapter.h
//  FT_AD_Base_IOS
//
//  Created by fotoable on 2020/1/2.
//  Copyright © 2020 fotoable. All rights reserved.
//
 
#ifndef FTBaseRewardAdapter_h
#define FTBaseRewardAdapter_h
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "FTBaseRewardDelegate.h"
 
@protocol FTBaseRewardAdapter <NSObject>

- (void) requestAd: (NSString *) adID;
- (BOOL) isAdValid;
- (BOOL) showAdWithViewController: (UIViewController * __nullable)viewController;
- (void) setRewardDelegate:(id<FTBaseRewardDelegate>)rewardDelegate;
@end
 

#endif /* FTBaseRewardAdapter_h */
