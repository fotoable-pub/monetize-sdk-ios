//
//  FTLoginFacebookAdapter.h
//  FTLoginFacebookAdapter
//
//  Created by fotoable on 2020/4/21.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTLoginFacebookAdapter.
FOUNDATION_EXPORT double FTLoginFacebookAdapterVersionNumber;

//! Project version string for FTLoginFacebookAdapter.
FOUNDATION_EXPORT const unsigned char FTLoginFacebookAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTLoginFacebookAdapter/PublicHeader.h>


#import <FTLoginFacebookAdapter/FTLoginFacebookCore.h>
#import <FTLoginFacebookAdapter/FTLoginFacebookManager.h>
