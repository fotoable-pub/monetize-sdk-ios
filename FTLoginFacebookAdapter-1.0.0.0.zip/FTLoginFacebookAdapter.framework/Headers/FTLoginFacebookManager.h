//
//  FTLoginFacebookManager.h
//  FTLoginFacebookAdapter
//
//  Created by fotoable on 2020/4/27.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FTLoginBaseAdapter/FTLoginBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTLoginFacebookManager : NSObject<FTLoginIBaseManager>

@end

NS_ASSUME_NONNULL_END
