//
//  FTLoginILoginPlatform.h
//  FTLoginBaseAdapter
//
//  Created by fotoable on 2020/4/21.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTLoginILoginPlatform_h
#define FTLoginILoginPlatform_h
#import <UIKit/UIKit.h>

typedef void (^FTLoginPlatFormBaseResultCallback)(NSMutableDictionary<NSString *, NSString *>* _Nullable authCredential,
NSError *_Nullable error);

typedef void (^FTLoginCheckStateResultCallback)(BOOL stateValid,
NSError *_Nullable error);

/// 调用第三方校验的接口
@protocol FTLoginILoginPlatform <NSObject>


@required

/// 登录
/// @param callBack 返回结果
- (void) loginWithViewController:(UIViewController *) viewController callBack:(FTLoginPlatFormBaseResultCallback _Nullable ) callBack;

/// 校验当前平台的登录是否有效
/// @param userIdentifier 第三方平台ID
/// @param callBack 检测结果
- (void) checkStateValid:(NSString * _Nonnull)userIdentifier callback:(FTLoginCheckStateResultCallback _Nullable ) callBack;

@end
#endif /* FTLoginILoginPlatform_h */
