//
//  FTLoginIBaseManager.h
//  FTLoginBaseAdapter
//
//  Created by fotoable on 2020/4/27.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTLoginIBaseManager_h
#define FTLoginIBaseManager_h
#import <UIKit/UIKit.h>

typedef void (^FTLoginBaseStatusCallback)(BOOL status,
NSError *_Nullable error);

/// 调用第三方校验的接口
@protocol FTLoginIBaseManager <NSObject>


@required


/// 周期回调(application:openURL:options:)
/// @param app UIApplication
/// @param url NSURL
/// @param options options
/// @param callback callback
- (BOOL) application:(UIApplication*)app openURL:(NSURL*)url options:(NSDictionary<NSString*, id>*)options callBack:(FTLoginBaseStatusCallback _Nullable) callback;


/// 周期回调(application:openURL:options:)
/// @param application application
/// @param launchOptions launchOptions
/// @param callback callback
- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions callBack:(FTLoginBaseStatusCallback _Nullable) callback;

/// 获取Adapter版本号
- (NSString *_Nullable)fetchVersion;

/// 获取第三方的版本号
- (NSString *_Nullable)fetchPlatformVersion;
@end

#endif /* FTLoginIBaseManager_h */
