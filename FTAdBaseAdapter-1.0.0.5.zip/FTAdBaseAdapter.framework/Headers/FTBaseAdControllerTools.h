//
//  FTBaseAdControllerTools.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTBaseAdControllerTools : NSObject
 
+ (instancetype)getInstance;
//获取根控制器
- (UIViewController *) getRootViewController;

///获取Window当前显示的视图控制器ViewController
- (UIViewController *)findCurrentShowingViewController;

/**
 *  获取Window当前显示的视图控制器ViewController
 *
 *  @param vc   从哪个界面开始分析
 *
 *  @return 当前显示的视图控制器ViewController
 */
- (UIViewController *)findCurrentShowingViewControllerFrom:(UIViewController *)vc;


#pragma mark - FindBelongViewControllerForView
- (nullable UIViewController *)findBelongViewControllerForView:(UIView *)view;
@end

NS_ASSUME_NONNULL_END
