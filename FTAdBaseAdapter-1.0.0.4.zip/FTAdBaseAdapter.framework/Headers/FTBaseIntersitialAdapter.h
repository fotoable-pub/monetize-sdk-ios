//
//  FTBaseIntersitialAdapter.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseIntersitialAdapter_h
#define FTBaseIntersitialAdapter_h
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "FTBaseIntersitialDelegate.h"

@protocol FTBaseIntersitialAdapter <NSObject>

/// 通过第三方广告ID进行请求
/// @param adID 第三方ID
@required
- (void) requestAd: (NSString *_Nonnull) adID;

/// 通过广告类型请求
/// @param adID SDK内部定义的广告ID
@optional 
- (void) requestAdByType: (NSString *_Nonnull) adID;

/// 判断广告是否可用
@required
- (BOOL) isAdValid;

/// 展示广告
/// @param viewController 要在此界面上展示
@required
- (BOOL) showAdWithViewController: (UIViewController * _Nonnull)viewController;

/// 设置回调
@required
- (void) setIntersitialDelegate: (id<FTBaseIntersitialDelegate> _Nullable)intersitialDelegate;
@end

#endif /* FTBaseIntersitialAdapter_h */
