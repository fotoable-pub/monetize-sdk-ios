//
//  FTBaseManagerDelegate.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/2/18.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseManagerDelegate_h
#define FTBaseManagerDelegate_h

#import "FTRewardBaseModel.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@protocol FTBaseManagerDelegate <NSObject>

/// @deprecated 初始化SDK结果
/// @param isSucc 初始化的结果
- (void) onInitResult: (BOOL) isSucc DEPRECATED_MSG_ATTRIBUTE("[Use onInitResult:error:]");

/// 初始化SDK结果NSError
/// @param isSucc
/// @param error  如果出错，有此值
@optional 
- (void) onInitResult: (BOOL) isSucc error:(NSError * _Nullable)error;

@end
#endif /* FTBaseManagerDelegate_h */
