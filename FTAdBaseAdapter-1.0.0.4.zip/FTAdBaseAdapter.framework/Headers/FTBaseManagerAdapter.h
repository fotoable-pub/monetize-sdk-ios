//
//  FTBaseManagerAdapter.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/2/18.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseManagerAdapter_h
#define FTBaseManagerAdapter_h

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <FTBaseManagerDelegate.h>

@protocol FTBaseManagerAdapter <NSObject>

/// 初始化SDK
/// @param adID 应用ID等
/// @param isDebug 初始化模式
@optional
- (void) initSDK: (NSString * _Nullable) adID isDebug: (BOOL) isDebug;

/// 初始化SDK
/// @param adID 应用ID等
/// @param ids 所有的广告位ID
/// @param isDebug 初始化模式
@optional
- (void) initSDK: (NSString * _Nullable) adID ids:(NSArray *) ids isDebug: (BOOL) isDebug;

///  设置监听
/// @param baseManagerDelegat 监听
@required
- (void) setBaseManagerDelegate:(id<FTBaseManagerDelegate> _Nullable)baseManagerDelegate;

/// 获取第三方的版本号
@required
- (NSString * _Nullable) fetchAdVersion;
@end

#endif /* FTBaseManagerAdapter_h */
