//
//  FTBaseBannerAdapter.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseBannerAdapter_h
#define FTBaseBannerAdapter_h

#import <UIKit/UIKit.h>
#import "FTBaseEnums.h"
#import "FTBaseBannerDelegate.h"

@protocol FTBaseBannerAdapter <NSObject>

@optional
/// 获取banner的高度
- (CGFloat)getBannerHeight;


/// 请求banner
/// @param adID 第三方广告ID
/// @param position 广告位置
/// @param size 广告尺寸
/// @param level 广告层级
/// @param viewController 展示的viewController
@required
- (void)requestAd:(NSString * _Nonnull)adID
   bannerPosition:(FTBase_AD_BANNER_POSITION)position
             size:(FTBase_AD_BANNER_SIZE)size
            level:(FTBase_AD_BANNER_Level)level
rootViewController:(UIViewController * _Nonnull)viewController;

- (BOOL)isAdValid;

/// 显示banner
/// @param viewController 暂时没有用到,可以传入nil
- (BOOL)showAdWithViewController:(UIViewController *_Nullable)viewController;


/// 隐藏banner
- (void)hiddenBannerAd;


/// 设置bannerDelegate
/// @param bannerDelegate delegate对象
- (void)setBannerDelegate:(id<FTBaseBannerDelegate> _Nullable)bannerDelegate;

@end

#endif /* FTBaseBannerAdapter_h */
