//
//  FTLogger.h
//  FTLogger
//
//  Created by fotoable on 2020/4/25.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTLogger.
FOUNDATION_EXPORT double FTLoggerVersionNumber;

//! Project version string for FTLogger.
FOUNDATION_EXPORT const unsigned char FTLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTLogger/PublicHeader.h>

#import <FTLogger/FTLog.h>
#import <FTLogger/FTLoggerHeader.h>

