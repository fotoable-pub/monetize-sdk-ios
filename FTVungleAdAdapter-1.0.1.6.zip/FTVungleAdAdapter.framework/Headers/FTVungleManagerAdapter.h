//
//  FTVungleManagerAdapter.h
//  FTVungleAdAdapter
//
//  Created by fotoable on 2020/3/2.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FTAdBaseAdapter/FTAdBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTVungleManagerAdapter : NSObject<FTBaseManagerAdapter>

//单例
+ (instancetype)getInstance;
/// 设置激励对外回调
/// @param adID 第三方广告ID
/// @param delegate 回调
- (void)setRewardDelegateWithAdID:(NSString *)adID delegate:(id)delegate;

/// 设置插播对外回调
/// @param adID 第三方广告ID
/// @param delegate 回调
- (void)setIntersitialDelegateWithAdID:(NSString *)adID delegate:(id)delegate;
/// 请求插播
/// @param adID 广告位
- (void)loadIntersitialAd:(NSString *)adID;
/// 请求激励
/// @param adID 广告位
- (void)loadRewardAd:(NSString *)adID;
@end

NS_ASSUME_NONNULL_END
