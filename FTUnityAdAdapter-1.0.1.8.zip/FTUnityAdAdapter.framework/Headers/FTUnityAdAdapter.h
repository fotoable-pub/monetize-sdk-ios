//
//  FTUnityAdAdapter.h
//  FTUnityAdAdapter
//
//  Created by fotoable on 2020/3/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTUnityAdAdapter.
FOUNDATION_EXPORT double FTUnityAdAdapterVersionNumber;

//! Project version string for FTUnityAdAdapter.
FOUNDATION_EXPORT const unsigned char FTUnityAdAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTUnityAdAdapter/PublicHeader.h>


#import <FTUnityAdAdapter/FTUnityIntersitialAdTask.h>
#import <FTUnityAdAdapter/FTUnityManagerAdapter.h>
#import <FTUnityAdAdapter/FTUnityRewardAdTask.h>
