//
//  FTAdmobMangerAdapter.h
//  FTAdmobAdapter
//
//  Created by fotoable on 2020/2/18.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FTAdBaseAdapter/FTAdBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTAdmobMangerAdapter : NSObject<FTBaseManagerAdapter>

@end

NS_ASSUME_NONNULL_END
