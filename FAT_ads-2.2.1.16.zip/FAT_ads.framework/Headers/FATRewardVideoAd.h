//
//  FATRewardAd.h
//  FAT_ads
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 FOTOABLE. All rights reserved.
//

#import <FAT_ads/FAT_ads.h>
#import <CoreMedia/CoreMedia.h>


NS_ASSUME_NONNULL_BEGIN

@protocol FATRewardAdDelegate;


@interface FATRewardVideoAd : FATBaseAd<IFATAd>
@property (nonatomic,weak) id<FATRewardAdDelegate> delegate;

/**
 Typed access to the id of the ad placement.
 */
@property (nonatomic, copy, readonly) NSString *adid;

/**
 The duration of the video, as a CMTime value.  Returns kCMTimeIndefinite if no video is loaded.
 */
@property (nonatomic, assign, readonly) CMTime duration;


/// 播放 rewardAfterSenconds 后发放奖励
@property (nonatomic, assign) CGFloat rewardInSenconds;

/// 播放多久后显示关闭按钮
@property (nonatomic, assign) CGFloat showCloseInSenconds;

@end

@protocol FATRewardAdDelegate <NSObject>

@optional


/// 视频广告点击下载 跳转
/// @param rewardedVideoAd <#rewardedVideoAd description#>
- (void)rewardedVideoAdDidClick:(FATRewardVideoAd *)rewardedVideoAd;


/// 视频广告加载成功
/// @param rewardedVideoAd <#rewardedVideoAd description#>
- (void)rewardedVideoAdDidLoad:(FATRewardVideoAd *)rewardedVideoAd;


/// 广告关闭成功
/// @param rewardedVideoAd <#rewardedVideoAd description#>
- (void)rewardedVideoAdDidClose:(FATRewardVideoAd *)rewardedVideoAd;



/// 广告即将关闭
/// @param rewardedVideoAd <#rewardedVideoAd description#>
- (void)rewardedVideoAdWillClose:(FATRewardVideoAd *)rewardedVideoAd;


/// 视频广告加载失败
/// @param rewardedVideoAd <#rewardedVideoAd description#>
/// @param error <#error description#>
- (void)rewardedVideoAd:(FATRewardVideoAd *)rewardedVideoAd didFailWithError:(NSError *)error;


/// 视频播放成功
/// @param rewardedVideoAd <#rewardedVideoAd description#>
- (void)rewardedVideoAdVideoComplete:(FATRewardVideoAd *)rewardedVideoAd;

/// video 即将展示
/// @param rewardedVideoAd <#rewardedVideoAd description#>
- (void)rewardedVideoAdWillVisible:(FATRewardVideoAd *)rewardedVideoAd;


/// video 展示成功
/// @param rewardedVideoAd <#rewardedVideoAd description#>
- (void)rewardedVideoAdDidVisible:(FATRewardVideoAd *)rewardedVideoAd;


/// 发送奖励的回调
/// @param rewardedVideoAd <#rewardedVideoAd description#>
- (void)rewardedVideoRewardDidSucceed:(FATRewardVideoAd *)rewardedVideoAd;
@end

NS_ASSUME_NONNULL_END
