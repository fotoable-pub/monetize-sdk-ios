//
//  IFATAd.h
//  FAT_ads
//
//  Created by fotoable on 2020/1/7.
//  Copyright © 2020 FOTOABLE. All rights reserved.
//

#ifndef IFATAd_h
#define IFATAd_h

@protocol IFATAd <NSObject>


- (instancetype)initWithAdID:(NSString *)adid;

- (void)loadAdData;

- (BOOL)showAdFromRootViewController:(UIViewController *)rootViewController;

@end

#endif /* IFATAd_h */
