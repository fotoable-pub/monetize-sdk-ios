//
//  FTBaseBannerDelegate.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseBannerDelegate_h
#define FTBaseBannerDelegate_h
#import <Foundation/Foundation.h>


@protocol FTBaseBannerDelegate <NSObject>

- (void)onBannerAdLoad:(NSString *_Nonnull)adID;

- (void)onBannerAdLoadFail:(NSString *_Nonnull)adID error:(NSError *_Nullable)error;

- (void)onBannerAdDisplay:(NSString *_Nonnull)adID;

- (void)onBannerAdDisplayFail:(NSString *_Nonnull)adID error:(NSError *_Nullable)error;

- (void)onBannerAdClose:(NSString *_Nonnull)adID;

- (void)onBannerAdClick:(NSString *_Nonnull)adID;

@end

#endif /* FTBaseBannerDelegate_h */
