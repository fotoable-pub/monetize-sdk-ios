//
//  FTBaseManagerAdapter.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/2/18.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseManagerAdapter_h
#define FTBaseManagerAdapter_h

#import <Foundation/Foundation.h>

typedef void(^Complete)(BOOL isSuccess,NSError * _Nullable error);

@protocol FTBaseManagerAdapter <NSObject>

@optional
/// 初始化SDK
/// @param appId 应用ID等
/// @param isDebug 初始化模式
- (void)initSDKWithAppId:(NSString *_Nullable)appId
                 isDebug:(BOOL)isDebug
                complete:(Complete _Nullable)complete;

/// 专用于初始化AdColony
/// @param appId 应用ID等
/// @param adIds 所有的广告位ID
/// @param isDebug 初始化模式
- (void)initAdColonySDKWithAppId:(NSString *_Nullable)appId
                           adIds:(NSArray * _Nullable)adIds
                         isDebug:(BOOL)isDebug
                        complete:(Complete _Nullable)complete;

/// 获取第三方的版本号
- (NSString *_Nullable)fetchAdVersion;
@end

#endif /* FTBaseManagerAdapter_h */
