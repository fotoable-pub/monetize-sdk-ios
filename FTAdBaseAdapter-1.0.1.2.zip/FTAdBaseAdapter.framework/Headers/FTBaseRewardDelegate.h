//
//  FTBaseRewardDelegate.h
//  FT_AD_Base_IOS
//
//  Created by fotoable on 2020/1/2.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseRewardDelegate_h
#define FTBaseRewardDelegate_h

#import <UIKit/UIKit.h>
#import <FTAdBaseAdapter/FTRewardBaseModel.h>

@protocol FTBaseRewardDelegate <NSObject>

- (void)onRewardAdLoad:(NSString * _Nonnull)adID;

- (void)onRewardAdLoadFail:(NSString * _Nonnull)adID error:(NSError * _Nullable)error;

- (void)onRewardAdDisplay:(NSString * _Nonnull)adID;

- (void)onRewardAdDisplayFail:(NSString * _Nonnull)adID error:(NSError * _Nullable)error;

- (void)onRewardAdClose:(NSString * _Nonnull)adID;

- (void)onRewardAdClick:(NSString * _Nonnull)adID;

- (void)onRewardAdReceiveReward:(NSString * _Nonnull)adID reward:(FTRewardBaseModel * _Nullable)reward;

- (void)onRewardAdComplete:(NSString * _Nonnull)adID;

@end
#endif /* FTBaseRewardDelegate_h */
