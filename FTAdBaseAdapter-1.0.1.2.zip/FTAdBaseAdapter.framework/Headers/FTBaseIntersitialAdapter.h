//
//  FTBaseIntersitialAdapter.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseIntersitialAdapter_h
#define FTBaseIntersitialAdapter_h

#import <UIKit/UIKit.h>
#import <FTAdBaseAdapter/FTBaseIntersitialDelegate.h>


@protocol FTBaseIntersitialAdapter <NSObject>

@required

/// 通过第三方广告ID进行请求
/// @param adID 第三方ID
- (void)requestAd:(NSString *_Nonnull)adID;

/// 判断广告是否可用
- (BOOL)isAdValid;

/// 展示广告
/// @param viewController 要在此界面上展示
- (BOOL)showAdWithViewController:(UIViewController *_Nonnull)viewController;

/// 设置回调
- (void)setIntersitialDelegate:(id<FTBaseIntersitialDelegate> _Nullable)intersitialDelegate;

@optional
/// 通过广告类型请求
/// @param adID SDK内部定义的广告ID
- (void)requestAdByType:(NSString *_Nonnull)adID;
@end

#endif /* FTBaseIntersitialAdapter_h */
