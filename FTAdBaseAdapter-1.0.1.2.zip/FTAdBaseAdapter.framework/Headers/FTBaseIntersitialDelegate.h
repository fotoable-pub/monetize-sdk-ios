//
//  FTBaseIntersitialDelegate.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseIntersitialDelegate_h
#define FTBaseIntersitialDelegate_h
#import <Foundation/Foundation.h>

@protocol FTBaseIntersitialDelegate <NSObject>

- (void)onIntersitialAdLoad:(NSString *_Nonnull)adID;

- (void)onIntersitialAdLoadFail:(NSString *_Nonnull)adID error:(NSError *_Nullable)error;

- (void)onIntersitialAdDisplay:(NSString *_Nonnull)adID;

- (void)onIntersitialAdDisplayFail:(NSString *_Nonnull)adID error:(NSError *_Nullable)error;

- (void)onIntersitialAdClose:(NSString *_Nonnull)adID;

- (void)onIntersitialAdClick:(NSString *_Nonnull)adID;

@end
#endif /* FTBaseIntersitialDelegate_h */
