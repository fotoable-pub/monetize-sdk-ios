//
//  FTAdBaseAdapter.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/2.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTAdBaseAdapter.
FOUNDATION_EXPORT double FTAdBaseAdapterVersionNumber;

//! Project version string for FTAdBaseAdapter.
FOUNDATION_EXPORT const unsigned char FTAdBaseAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTAdBaseAdapter/PublicHeader.h>

#import <FTAdBaseAdapter/FTBaseRewardAdapter.h>
#import <FTAdBaseAdapter/FTBaseRewardDelegate.h>
#import <FTAdBaseAdapter/FTBaseIntersitialAdapter.h>
#import <FTAdBaseAdapter/FTBaseIntersitialDelegate.h>
#import <FTAdBaseAdapter/FTBaseBannerAdapter.h>
#import <FTAdBaseAdapter/FTBaseBannerDelegate.h>
#import <FTAdBaseAdapter/FTRewardBaseModel.h>
#import <FTAdBaseAdapter/FTBaseEnums.h>
#import <FTAdBaseAdapter/FTBaseManagerAdapter.h>
