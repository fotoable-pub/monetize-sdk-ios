//
//  FTLoginBaseAdapter.h
//  FTLoginBaseAdapter
//
//  Created by fotoable on 2020/4/21.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTLoginBaseAdapter.
FOUNDATION_EXPORT double FTLoginBaseAdapterVersionNumber;

//! Project version string for FTLoginBaseAdapter.
FOUNDATION_EXPORT const unsigned char FTLoginBaseAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTLoginBaseAdapter/PublicHeader.h>

#import <FTLoginBaseAdapter/FTLoginILoginPlatform.h>
