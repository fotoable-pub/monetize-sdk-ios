//
//  FTLoginBaseConfig.h
//  FTSDKLogin
//
//  Created by fotoable on 2020/3/24.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTLoginBaseConfig : NSObject

/// debug模式
@property (nonatomic, assign) BOOL isDebug;
/// 是否打印日志输出
@property (nonatomic, assign) BOOL isPrintLog;


@end

NS_ASSUME_NONNULL_END
