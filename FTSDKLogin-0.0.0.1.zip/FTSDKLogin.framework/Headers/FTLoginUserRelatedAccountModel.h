//
//  FTLoginUserRelatedAccountModel.h
//  FTSDKLogin
//
//  Created by fotoable on 2020/4/2.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FTLoginEnums.h"

NS_ASSUME_NONNULL_BEGIN

@interface FTLoginUserRelatedAccountModel : NSObject

@property(nonatomic, assign) FTLogin_PLATFORM platform;
@property(nonatomic, copy) NSString *openid;
@property(nonatomic, copy) NSString *avatar;
@property(nonatomic, copy) NSString *email;
@property(nonatomic, copy) NSString *name;
@property(nonatomic, copy) NSString *createdAtTime;
@property(nonatomic, copy) NSString *updatedAtTime;

@end

NS_ASSUME_NONNULL_END
