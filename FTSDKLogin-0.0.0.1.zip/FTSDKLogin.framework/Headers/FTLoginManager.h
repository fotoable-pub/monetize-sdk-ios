//
//  FTLoginManager.h
//  FTSDKLogin
//
//  Created by fotoable on 2020/3/23.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FTLoginEnums.h"
#import "FTLoginUserModel.h"
#import "FTLoginBaseConfig.h"

@protocol FTLoginManagerDelegate <NSObject>

@required
//log输出内容
- (void) onLog: (FTLogin_LOG_TYPE) logType logLevel:(FTLogin_LOG_LEVEL_TYPE) logLevel logValue: (NSString *_Nullable)log;
@end

///登录结果回调
typedef void (^FTLoginResultCallback)(FTLoginUserModel* _Nullable userModel,
NSError *_Nullable error);
///退出登录
typedef void (^FTLoginOutResultCallback)(BOOL isSucc, NSError *_Nullable error);

NS_ASSUME_NONNULL_BEGIN

@interface FTLoginManager : NSObject

@property (nonatomic, weak) id<FTLoginManagerDelegate> delegate;

+ (FTLoginManager *)SharedLoginManager;

/// 初始化SDK
/// @param isDebug 测试模式
- (void) initSDK:(BOOL) isDebug;

/// 登录（如果游戏首次发版、或者没有自己的用户系统建议使用此方法，如果游戏已有自己的用户系统，建议使用【login:withDeviceID:callBack:】方法）
/// @param loginKind 登录的平台
- (void) login:(FTLogin_Kind) loginKind callBack:(FTLoginResultCallback) callback;

/// 登录（为了兼用游戏的用户系统，所以需要游戏传递设备ID，如果游戏首次发版、或者没有自己的用户系统建议使用【login:callBack:】方法登录）
/// @param loginKind 登录的平台（游客、apple等）
/// @param deviceID 设备ID
/// @param callback 登录结果
- (void) login:(FTLogin_Kind) loginKind withDeviceID:(NSString *_Nullable) deviceID callBack:(FTLoginResultCallback) callback;

/// 推出登录
- (void) loginOut:(FTLoginOutResultCallback) callback;

/// 获取基本的配置信息
- (FTLoginBaseConfig *) getLoginbaseConfig; 

@end

NS_ASSUME_NONNULL_END
