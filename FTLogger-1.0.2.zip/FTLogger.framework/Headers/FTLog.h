//
//  FTLog.h
//  FTLogger
//
//  Created by fotoable on 2020/4/27.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FTLogger/FTLoggerHeader.h>


NS_ASSUME_NONNULL_BEGIN

@interface FTLog : NSObject

@property (nonatomic, copy, readonly) NSString *appId;


+ (void)startWithAppId:(NSString *)appId;

+ (void)logWithPlatformType:(FTLogPlatformType)platformType
                        tag:(NSString *)tag
                      level:(FTLogLevel)level
                    message:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
