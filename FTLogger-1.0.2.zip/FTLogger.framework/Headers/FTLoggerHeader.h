//
//  FTLoggerHeader.h
//  FTLogger
//
//  Created by fotoable on 2020/4/29.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTLoggerHeader_h
#define FTLoggerHeader_h

typedef NS_ENUM(NSUInteger, FTLogLevel) {
    FTLogLevelNormal = 1,
    FTLogLevelWarning = 2,
    FTLogLevelError = 3,
};

typedef NS_ENUM(NSUInteger, FTLogPlatformType) {
    FTLogPlatformTypeUndefine = 0,
    FTLogPlatformTypeMediation = 1,
    FTLogPlatformTypeArlinton = 2,
    FTLogPlatformTypeAuth = 3,
    FTLogPlatformTypeStorage = 4,
    FTLogPlatformTypeIAP = 5,
    FTLogPlatformTypeCrash = 6,
    FTLogPlatformTypeBI = 7,
};

#endif /* FTLoggerHeader_h */
