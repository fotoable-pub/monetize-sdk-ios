//
//  FTAdcolonyAdAdapter.h
//  FTAdcolonyAdAdapter
//
//  Created by fotoable on 2020/3/22.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FTAdcolonyAdAdapter.
FOUNDATION_EXPORT double FTAdcolonyAdAdapterVersionNumber;

//! Project version string for FTAdcolonyAdAdapter.
FOUNDATION_EXPORT const unsigned char FTAdcolonyAdAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTAdcolonyAdAdapter/PublicHeader.h>


#import <FTAdcolonyAdAdapter/FTAdcolonyIntersitialAdTask.h>
#import <FTAdcolonyAdAdapter/FTAdcolonyRewardAdTask.h>
#import <FTAdcolonyAdAdapter/FTAdcolonyManagerAdapter.h>

