//
//  FTAdcolonyManagerAdapter.h
//  FTAdcolonyAdAdapter
//
//  Created by fotoable on 2020/3/4.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FTAdBaseAdapter/FTAdBaseAdapter.h>

NS_ASSUME_NONNULL_BEGIN


@protocol FTAdcolonyManagerDelegate <NSObject>

- (void)adColonyDidFailToLoadZoneId:(NSString *)zoneId error:(NSError *_Nonnull)error;

- (void)adColonyInterstitialDidLoadWithZoneId:(NSString *)zoneId;

- (void)adColonyInterstitialWillOpenWithZoneId:(NSString *)zoneId;

- (void)adColonyInterstitialDidCloseWithZoneId:(NSString *)zoneId;

- (void)adColonyInterstitialDidReceiveClickWithZoneId:(NSString *)zoneId;

- (void)adColonyInterstitialExpiredWithZoneId:(NSString *)zondId;

@optional
- (void)adColonyInterstitialRewardAdCompleteZoneId:(NSString *)zoneId;

- (void)adColonyInterstitialReceiveReward:(NSString *)zoneId type:(NSString *)type amount:(NSString *)amount;
@end

@interface FTAdcolonyManagerAdapter : NSObject<FTBaseManagerAdapter>

//单例
+ (instancetype)getInstance;

- (BOOL)isValid:(NSString *)zoneId;
- (BOOL)showAdWithZoneId:(NSString *)zoneId presentViewController:(UIViewController *)viewController;
- (void)requestZoneId:(NSString *)zondId;


- (void)addListener:(id<FTAdcolonyManagerDelegate>)listener zoneId:(NSString *)zondId;
- (void)removeListenerForZoneId:(NSString *)zoneId;
@end

NS_ASSUME_NONNULL_END
