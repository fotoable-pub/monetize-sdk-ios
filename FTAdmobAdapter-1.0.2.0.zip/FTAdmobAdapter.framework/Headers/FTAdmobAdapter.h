//
//  FTAdmobAdapter.h
//  FTAdmobAdapter
//
//  Created by fotoable on 2020/1/21.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FTAdmobAdapter.
FOUNDATION_EXPORT double FTAdmobAdapterVersionNumber;

//! Project version string for FTAdmobAdapter.
FOUNDATION_EXPORT const unsigned char FTAdmobAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTAdmobAdapter/PublicHeader.h>


#import <FTAdmobAdapter/FTAdmobBannerAdTask.h>
#import <FTAdmobAdapter/FTAdmobIntersitialAdTask.h>
#import <FTAdmobAdapter/FTAdmobRewardAdTask.h>
#import <FTAdmobAdapter/FTAdmobMangerAdapter.h>




