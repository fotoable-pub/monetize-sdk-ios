//
//  FTBaseIntersitialAdapter.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseIntersitialAdapter_h
#define FTBaseIntersitialAdapter_h
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "FTBaseIntersitialDelegate.h"

@protocol FTBaseIntersitialAdapter <NSObject>

- (void) requestAd: (NSString *) adID;
- (BOOL) isAdValid;
- (BOOL) showAdWithViewController: (UIViewController * __nullable)viewController;
- (void) setIntersitialDelegate: (id<FTBaseIntersitialDelegate>)intersitialDelegate;
@end

#endif /* FTBaseIntersitialAdapter_h */
