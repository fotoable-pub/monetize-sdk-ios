//
//  FTRewardBaseModel.h
//  FT_AD_Base_IOS
//
//  Created by fotoable on 2020/1/2.
//  Copyright © 2020 fotoable. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FTRewardBaseModel : NSObject

@property(nonatomic, copy) NSString *type;
@property(nonatomic, copy) NSString *amount;
@end

NS_ASSUME_NONNULL_END
