//
//  FTBaseIntersitialDelegate.h
//  FTAdBaseAdapter
//
//  Created by fotoable on 2020/1/3.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseIntersitialDelegate_h
#define FTBaseIntersitialDelegate_h
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol FTBaseIntersitialDelegate <NSObject>

- (void) onIntersitialAdLoad: (NSString *)adID;

- (void) onIntersitialAdLoadFail: (NSString *)adID error:(NSError *)error;

- (void) onIntersitialAdDisplay: (NSString *)adID;

- (void) onIntersitialAdDisplayFail: (NSString *)adID error:(NSError *)error;

- (void) onIntersitialAdClose: (NSString *)adID;

- (void) onIntersitialAdClick: (NSString *)adID;

@end
#endif /* FTBaseIntersitialDelegate_h */
