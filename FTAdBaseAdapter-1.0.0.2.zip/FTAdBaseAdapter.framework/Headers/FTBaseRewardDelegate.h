//
//  FTBaseRewardDelegate.h
//  FT_AD_Base_IOS
//
//  Created by fotoable on 2020/1/2.
//  Copyright © 2020 fotoable. All rights reserved.
//

#ifndef FTBaseRewardDelegate_h
#define FTBaseRewardDelegate_h

#import "FTRewardBaseModel.h" 
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@protocol FTBaseRewardDelegate <NSObject>

- (void) onRewardAdLoad: (NSString *)adID;

- (void) onRewardAdLoadFail: (NSString *)adID error:(NSError *)error;

- (void) onRewardAdDisplay: (NSString *)adID;

- (void) onRewardAdDisplayFail: (NSString *)adID error:(NSError *)error;

- (void) onRewardAdClose: (NSString *)adID;

- (void) onRewardAdClick: (NSString *)adID;

- (void) onRewardAdReceiveReward: (NSString *)adID reward:(FTRewardBaseModel *) reward;

- (void) onRewardAdComplete: (NSString *)adID;

@end
#endif /* FTBaseRewardDelegate_h */
