//
//  FATInterstitialAdModel.h
//  FAT_ads
//
//  Created by 傅瑶 on 2019/6/16.
//  Copyright © 2019 FOTOABLE. All rights reserved.
//

#import "FATBaseModel.h"
#import "FATAdModel.h"

NS_ASSUME_NONNULL_BEGIN



/*
 {
 adid = 2359;
 bundle = 1273162445;
 ctrk =             (
 "https://arlington.ftads.net/track?type=c&bid=3c1b0e05-a60f-453a-a398-b2c8e794517e&adid=2359&adsetid=217&appid=100036&placementId=161&deviceID=&android_id=&gaid=&idfa=42A2369E-26D4-4174-BE7E-3BCE5C3CDC78&brand=iPhoneSimulator&model=iPhoneSimulator&os=1&os_version=12.2&country="
 );
 icon = "https://adsres.ftstats.com/arlington/201906/201906142031105132073748535.jpeg";
 id = 161;
 img =             {
 h = 691;
 url = "https://adsres.ftstats.com/arlington/201906/201906171530075166959163163.png";
 w = 599;
 };
 itrk =             (
 "https://impression.appsflyer.com/id1273162445?c=TestApp_0616&af_siteid=100036&af_sub_siteid=161&af_channel=Test_placement&af_ad_id=2359&pid=fotoable_int&af_viewthrough_lookback=1d&clickid=&android_id=&advertising_id=&idfa=42A2369E-26D4-4174-BE7E-3BCE5C3CDC78",
 "https://arlington.ftads.net/track?type=i&bid=3c1b0e05-a60f-453a-a398-b2c8e794517e&adid=2359&adsetid=217&appid=100036&placementId=161&deviceID=&android_id=&gaid=&idfa=42A2369E-26D4-4174-BE7E-3BCE5C3CDC78&brand=iPhoneSimulator&model=iPhoneSimulator&os=1&os_version=12.2&country="
 );
 name = "Word Crossy - A crossword game";
 score = "4.5";
 turl = "https://itunes.apple.com/us/app/id1273162445";
 type = 0;
 video = "<null>";
 }
 */
@interface FATInterstitialAdModel : FATAdModel

@property (nonatomic, strong) FATAdImage *img;
@property (nonatomic, strong) FATAdVideo *video;

@end



NS_ASSUME_NONNULL_END
